Choose a client from 1/2
resolver is needed on server to compile the cnc!!!
add the includes to what selfreps you want in the bot/client!
(:
also add them onto the server!!